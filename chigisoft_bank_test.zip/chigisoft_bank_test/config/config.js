const mysql = require('mysql');
const pool = mysql.createPool({
    user: "root",
    password: "",
    database: "node_test",
    hostname: "localhost",
  });

  module.exports = pool;