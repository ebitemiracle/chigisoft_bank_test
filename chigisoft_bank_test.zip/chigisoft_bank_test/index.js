// const mysql = require('mysql');
const express = require('express');
const app = express();
app.use(express.json());
// Importing router
const userRouter = require('./api/user/user.route');
const transactionRouter = require('./api/transaction/transaction.route');

app.get('/', (req, res)=>{
res.send("Welcome to my website");
});

app.use('/api/user', userRouter);
app.use('/api/transaction', transactionRouter);

// test
// const data = {
//     age: 34,
//     complexion: 'Fair'
// }
// const {fullname='My sugar mommy is Tessy baby'} = data;
// console.log(fullname);

port = process.env.PORT || 3000;
app.listen(port, ()=>{
    console.log(`listening on port ${port}`);
});
