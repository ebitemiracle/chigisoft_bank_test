const db = require("../../config/config.js");

module.exports = {
    getBalance:(userId, callback)=>{
        db.query(`SELECT ((SELECT SUM(amount) FROM transactions WHERE transaction_type='credit' AND recipient_id=?) - (SELECT SUM(amount) FROM transactions WHERE transaction_type='debit' AND recipient_id=?)) AS balance_amount `,
        [userId, userId],
        (error, result)=>{
            if (error){
                return callback({
                    status: false,
                    message: error
                });
            }
            if(!result[0]){
                return callback(null, {
                    status: false,
                    message: 'Balance not retrieved'
                });
            }
            return callback(null, {
                status: true,
                message: 'Balance retrieved successfully',
                result
            })
        }
        )
    },

    transferFunds:(data, callback)=>{
        const { recipientAccountNumber, amount, senderAccountNumber, transaction_type } = data;
        db.query(`INSERT INTO transaction SET recipient_account_number=?, amount=? sender_account_number=?, transaction_type, date_registered=NOW()`,
        Object.values(data),
        (error, result) =>{
            if (error){
            return callback({
                    status: false,
                    message: error
                })
            }
            if (!result[0]) {
                return callback(null, {
                    status: false,
                    message: 'Something went wrong'
                });
            }
            // This happens when the transaction is successful
            return callback(null, {
                status: true,
                message: 'Hey, you have successfully sent the sum of '+amount+' to '+recipientAccountNumber
            })
            
        }
        )
    },

    getTransactionHistory:(userId, callback) => {
        // Given more time I will be able to complete this API
    }
}