const transaction = require('./transaction.controller');
const {Router} = require('express');
const router = Router();

router.get('/getbalance/:userId', transaction.getBalance);
router.get('/transferfunds', transaction.transferFunds);
router.get('/gettransactionhistory', transaction.getTransactionHistory);

module.exports = router;