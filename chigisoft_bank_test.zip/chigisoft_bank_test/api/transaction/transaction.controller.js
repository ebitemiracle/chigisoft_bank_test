const transaction = require('./transaction.model');

module.exports = {
    getBalance: (req, res)=>{
        const userId = req.params.userId;
        transaction.getBalance(userId, (error, result)=>{
            if (error) {
               return res.status(400).send(error);
            }
            res.status(200).send(result);
        })
    },

    transferFunds: (req, res)=>{
        body = req.body;
        transaction.transferFunds(body, (error, result)=>{
            if (error) {
               return res.status(400).send(error);
            }
            res.status(200).send(result);

        });
    }
}