const db = require("../../config/config.js");
const validator = require("validator");

module.exports = {
  // This api is for user registration
  registerUser: (data, callback) => {
    const { fullname, email, password } = data;
    // Validation goes here
    if (fullname.length == 0) {
      return callback({
        status: false,
        message: "Your name is required",
      });
    }

    if (validator.isEmail(email) == false) {
      return callback({
        status: false,
        message: "Email is not valid",
      });
    }

    if (password.length < 6) {
      return callback({
        status: false,
        message: "Password must be at least 6 characters",
      });
    }

    db.query(
      `INSERT INTO users SET fullname = ?, email = ?, password = MD5(?), date_registered = NOW()`,
      Object.values(data),
      (error, result) => {
        if (error) {
          return callback({
            status: false,
            error,
          });
        }
        callback(null, {
          status: true,
          message:
            "Hey " + fullname +", your account has been registered successfully",
        });
      }
    );
  },

  // This api is for user biodata modification
  editUser: (data, callback) => {
    const {fullname, userId} = data;
    if (fullname.length === 0) {
        return callback({
            status: false,
            message: 'Please enter your full name'
        });
    }

    db.query(
      `UPDATE users SET fullname = ? WHERE user_id = ?`,
      Object.values(data),
      (error, result) => {
        if (error) {
          return callback({
            status: false,
            message: error
          });
        }
        callback(null, {
            status: true,
            message: 'Your information was updated successfully'
        });
      }
    );
  },

  // Fetch user information
  getUser: (userId, callback) => {
    // const { userId } = data;
    db.query(
      `SELECT * FROM users WHERE user_id = ? AND deleted=0`,
      userId,
      (error, result) => {
        if (error) {
          return callback(error, null);
        }
        if (!result[0]) {
          return callback(null, {
            status: false,
            message: "User not found",
            result: null,
          });
        }
        return callback(null, {
          status: true,
          message: "User found",
          result
        });
      }
    );
  },
};
