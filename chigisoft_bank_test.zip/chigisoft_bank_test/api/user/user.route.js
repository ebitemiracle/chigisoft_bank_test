const user = require('./user.controller');

const {Router} = require('express');

const router = Router();

router.post('/createuser', user.registerUser);
router.patch('/edituser', user.editUser);
router.get('/getuser/:userId', user.getUser);

module.exports = router;