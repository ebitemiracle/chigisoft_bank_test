const user = require('./user.model');
module.exports = {
    registerUser:(req, res)=>{
        body = req.body;
        user.registerUser(body, (error, result)=>{
            if (error) {
            return res.status(400).send(error);
            }
            return res.status(200).send(result);
        })
    },

    editUser:(req, res)=>{
        body = req.body;
        user.editUser(body, (error, result)=>{
            if (error) {
            return res.status(400).send(error);
            }
            res.status(200).send(result);
        })
    },

    getUser:(req, res)=>{
        userId = req.params.userId;
        user.getUser(userId, (error, result)=>{
            if (error) {
            return res.status(400).send(error);
            }
            res.status(200).send(result);
        });
    }

    
}